/**
 * @author Jose Garvin Victoria
 *
 */
package net.josegarvin.StAX;